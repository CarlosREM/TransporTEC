package com.transportec;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class BusesTEC extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buses_tec);
    }
}
